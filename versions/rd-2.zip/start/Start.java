import org.lwjgl.LWJGLException;
import com.mojang.minecraft.RubyDung;

public class Start
{
	public static void main(String[] args) throws LWJGLException {
		RubyDung.main(args);
	}

}