import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import net.minecraft.src.Minecraft;

public final class GameWindowListener extends WindowAdapter
{
	final Minecraft mc;
	final Thread thread;

	public GameWindowListener(Minecraft mc, Thread thread) {
		this.mc = mc;
		this.thread = thread;
	}

	public void windowClosing(WindowEvent event) {
		try {
			this.thread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}
}
